from pathlib import Path

PAPERQA_DIR = Path.home() / ".paperqa"
